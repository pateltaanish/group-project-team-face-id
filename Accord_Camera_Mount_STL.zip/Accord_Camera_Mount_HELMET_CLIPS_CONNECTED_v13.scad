// Accord camera mount | standalone, millimeters | bench mock-up.
// Measure the external trim cap before changing these example dimensions.
// X runs from the adjuster toward the window area. Lens looks out along -Y.
view = "Assembly"; // [Assembly,Mount only,Saddle and rail,Saddle only,Rail only,Carriage]
// Seatbelt-holder dimensions from the supplied reference image, in millimeters.
// The holder is modeled as a downward-opening U around the measured structure.
adjuster_width = 61;       // 61 mm: narrower width at the curved top
bottom_width = 80;         // 80 mm: wider horizontal width at the bottom
adjuster_top_depth = 80;   // 80 mm: depth of the saddle around the holder
leg_drop = 80;             // 80 mm: curved top-to-bottom side path
side_clearance = 0.6;      // each side
travel = 45;
slide_position = 0.70;     // [0:0.01:1]
camera_hole_pitch_x = 21;
camera_hole_pitch_z = 14;
camera_model_length = 90.82; // imported model overall X size, mm
camera_model_width = 29;     // assembled front/back model Y envelope, mm
camera_model_height = 44;    // imported model overall Z size, mm
camera_model_clearance = 1;
camera_stand_height = 5;     // 0.5 cm stand between slider and camera mount
camera_stand_width = 42;
camera_stand_depth = 29;
camera_mount_overlap = 2;
camera_model_front_file = "Pi_IR-CUT_CAM_v20_front.stl";
camera_model_back_file = "Pi_IR-CUT_CAM_v20_back.stl";
show_mock_adjuster = false; // translucent reference volume
/* [Hidden] */
$fn=48;
wall=3; roof=4; rail_w=26;
groove_relief=8; // 8 mm: measured side-groove relief
roof_curve_rise=6; // estimated inner roof rise; increase for a deeper curved fit
rail_attach_overlap=1; // same saddle/rail overlap used by the original SCAD
latch_inset=8;          // inward hook length at the bottom of each side cheek
latch_width=10;         // latch width along the 40 mm holder-depth direction
latch_drop=3;           // downward hook at the latch tip
latch_thickness=3;
gap=adjuster_width+2*side_clearance;
edge=gap/2+wall;
length=camera_model_length+2*camera_model_clearance;
rail_len=length+travel;
car_x=edge+travel*slide_position;
cam_x=length/2;
$vpr=[73,0,18];
$vpt=[(edge+rail_len-edge)/2,0,9];
$vpd=(rail_len+2*edge)*2.25;

function roof_curve(width,rise,n=16) =
    [for(i=[0:n])
        [-width/2 + width*i/n,
         rise*sqrt(max(0,1-pow(2*i/n-1,2)))]];

// Smoothly flares the side walls from the 61 mm top to the 80 mm bottom.
function side_curve(top_half,bottom_half,height,n=16) =
    [for(i=[0:n]) let(t=i/n, e=t*t*(3-2*t))
        [top_half+(bottom_half-top_half)*e, -height*t]];

// One flexible hook at the bottom of a side cheek. The mirrored pair locks
// under the lower edge of the holder without making the saddle a solid block.
module bottom_latch(){
    translate([-edge+wall-0.5,-latch_width/2,-leg_drop+1])
        hull(){
            cube([latch_inset,latch_width,latch_thickness]);
            translate([latch_inset-2,0,-latch_drop])
                cube([2,latch_width,latch_thickness]);
        }
}

// Rounded shell primitive used to form the helmet-like saddle.
module rounded_body(width,depth,center_z,zsize,center_y=0){
    translate([0,center_y,center_z])
        scale([width/2,depth/2,zsize/2]) sphere(1);
}

module saddle_outer(){
    // One continuous lofted helmet body.  The rear/top station is higher than
    // the front/top station, creating the downward-curving roof seen in the
    // reference photo; the lower stations flare outward to 80 mm.
    hull(){
        // Front top: lower edge of the curved roof.
        rounded_body(61,28,-10,16,-25);
        // Back top: raised crown of the helmet.
        rounded_body(61,28,8,16,25);
        // Flaring lower front and lower back.
        rounded_body(80,20,-74,18,-30);
        rounded_body(80,20,-74,18,30);
    }
}

module saddle_inner(){
    // Matching inner loft leaves the roof and side walls while opening the
    // bottom so the saddle can slip over the holder.
    hull(){
        rounded_body(55,20,-7,10,-24);
        rounded_body(55,20,3,10,24);
        rounded_body(74,14,-88,18,-29);
        rounded_body(74,14,-88,18,29);
    }
}

// Two bottom retention hooks.  They are fused into the lower front rim and
// point inward so they can catch the holder's lower grooves.
module bottom_clip(xpos){
    translate([xpos-4,-39,-84])
        hull(){
            cube([8,8,7]);
            translate([0,8,-4]) cube([8,7,4]);
        }
}

// One continuous hollow cap wraps over the holder like a helmet. The outer
// body has a visible recessed middle and a flared lower section instead of a
// single straight U profile.
module saddle(){
    union(){
        difference(){
            saddle_outer();
            saddle_inner();
            // Rear entry opening.  The roof remains intact, while the back wall
            // below the roof is removed so the helmet can slide onto the holder.
            translate([-100,adjuster_top_depth/2-10,-leg_drop-10])
                cube([200,20,leg_drop+10]);
        }
        bottom_clip(-22);
        bottom_clip(22);
    }
}
// Camera-support rail is deliberately separate from the saddle so the two
// pieces can be printed and test-fitted independently.
module rail(){
    // Center the rail on the saddle's Y-axis, as in the original SCAD.
    translate([edge-rail_attach_overlap,-rail_w/2,0]) difference(){
        union(){
            cube([rail_len+1,rail_w,roof]);
            for(y=[0,rail_w-2])
                translate([0,y,roof-0.1]) cube([rail_len+1,2,3.1]);
        }
        hull() for(x=[1+length/2,1+length/2+travel])
            translate([x,rail_w/2,-1]) cylinder(d=3.6,h=roof+2);
    }
}
// Positive overlap between the rail and the helmet shell.  This prevents the
// rail from appearing to float inside the hollow saddle.
module rail_helmet_bridge(){
    // The lower block reaches into the helmet's top wall and overlaps the
    // rail's left end; the upper block makes the connection visible and rigid.
    hull(){
        translate([24,-rail_w/2,-2])
            cube([12,rail_w,10]);
        translate([edge-1,-rail_w/2,-2])
            cube([12,rail_w,10]);
    }
}
// Saddle and rail are one connected printable mount, using the same direct
// union structure as the original SCAD file.
module base(){
    union(){
        saddle();
        rail_helmet_bridge();
        translate([edge-1,-rail_w/2,0]) difference(){
            union(){
                cube([rail_len+1,rail_w,roof]);
                for(y=[0,rail_w-2])
                    translate([0,y,roof-0.1]) cube([rail_len+1,2,3.1]);
            }
            hull() for(x=[1+length/2,1+length/2+travel])
                translate([x,rail_w/2,-1]) cylinder(d=3.6,h=roof+2);
        }
    }
}
module carriage(){
    difference(){
        // Orange slider plate only. The Printables camera mount sits directly
        // on this plate; the former middle orange support block is removed.
        translate([0,-camera_model_width/2-1,0])
            cube([length,camera_model_width+2,4]);
        translate([length/2,0,-1]) cylinder(d=3.6,h=6);
        for(x=[cam_x-camera_hole_pitch_x/2,cam_x+camera_hole_pitch_x/2],
            z=[9,9+camera_hole_pitch_z])
            translate([x,-6,z]) rotate([90,0,0]) cylinder(d=2.4,h=7);
        // Tie slots for the converter at the adjuster end of the carriage.
        for(x=[4,22]) translate([x,-4,-1]) cube([2,8,6]);
    }
}
module camera_stand(){
    translate([(length-camera_stand_width)/2,-camera_stand_depth/2,4])
        cube([camera_stand_width,camera_stand_depth,camera_stand_height]);
}
module camera_mount_with_stand(){
    // The 5 mm stand overlaps the camera model by 2 mm. Keeping both inside
    // one union makes the stand and mount one printable structure.
    union(){
        color("#e19a44") camera_stand();
        translate([0,0,4+camera_stand_height-camera_mount_overlap]) camera_model();
    }
}
// Real Raspberry Pi IR-cut camera mount converted from the downloaded STEP.
// The source contains separate front and back pieces, imported together.
module camera_model(){
    color("#30363b")
        translate([46.66,-11.5,14.0])
            import(camera_model_front_file);
    color("#3d4650")
        translate([46.66,-11.5,14.0])
            import(camera_model_back_file);
}
if(view=="Carriage") {
    color("#e19a44") carriage();
    color("#e19a44") camera_stand();
}
else if(view=="Saddle only") color("#6d8191") saddle();
else if(view=="Rail only") color("#718797") rail();
else {
    color("#718797") base();
    if(view!="Saddle and rail") translate([car_x,0,roof]){
        color("#e19a44") carriage();
        if(view=="Assembly") camera_mount_with_stand();
    }
    if(show_mock_adjuster && view=="Assembly")
        %translate([-adjuster_width/2,-adjuster_top_depth/2,-leg_drop-9])
            cube([adjuster_width,adjuster_top_depth,leg_drop+9]);
}
